var app= angular.module("myApp",['ngRoute','ngStorage']);

app.config(function($routeProvider)
{
    $routeProvider.when('/login', {
        controller: 'controller1',
        templateUrl: 'js/views/login.html',
                }).when('/view',{
        controller:'controller2',
        templateUrl: 'js/views/view.html',
                }).when('/singup', {
        controller: 'controller1',
        templateUrl: 'js/views/singup.html',
                }).when('/user',{
        controller:'controller2',
        templateUrl: 'js/views/userinfo.html',
                }).otherwise({
        redirectTo:'/login'
        });
});

