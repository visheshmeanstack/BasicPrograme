app.controller("controller1",function($scope,loginservice,$location){
          $scope.result=function()
                  {
                loginservice.goto($scope.name , $scope.pass);
                $scope.name="";
                $scope.pass="";
                      console.log($scope.name);
                          }

          $scope.create=function()
                  {
            $location.path('/singup');
                  }
          $scope.saveMyData=function()
                {
            loginservice.savedata($scope.fname,$scope.lname, $scope.uname,$scope.upass);
            $location.path('/login');
                }
             });
app.controller("controller2",function($scope,$localStorage,$location){
          $scope.clickUser=false;
          $scope.cclick=$localStorage.z;
          $scope.name1=[
           {fname: 'shilpa', lname: 'kumar', designation: 'Javascript Trainee'},
           {fname: 'rita'  , lname: 'kaur' , designation: 'software'},
           {fname: 'sonia' , lname: 'rana' , designation: 'Sr software Engg'}
                     ];
            //console.log($scope.fname);
          $scope.now=new Date();
          $scope.save=function()
           {
          $scope.name1.push({'fname':$scope.fname,'lname':$scope.lname,'designation':$scope.designation});
          $scope.fname="";
          $scope.lname="";
          $scope.designation="";

             }
          $scope.remove=function(index)
             {
          $scope.name1.splice(index,1);
             }
          $scope.logout=function()
             {
          $location.path('/login');
             }
          $scope.backup=function()
             {
          $location.path('/view');
             }

             });


