app.service('loginservice',function($location,$localStorage){

   this.contact= [{
       firstname:'vishesh',
       lastname:'Tanwar',
       name:'vishesh',
       password:'admin@123'}];
   // this.contact=[];
    //var myname=[];
    this.savedata=function(fname,lname,name,pass) {
        this.contact.push({'firstname': fname, 'lastname': lname, 'name': name, 'password': pass});
       // console.log(this.contact);

      $localStorage.myname = this.contact;
        //  localStorage.setItem('myname',this.contact);
        //  localStorage.getItem('myname');
        //console.log(a);

    }
       //$localStorage.myname = this.contact;
       //console.log(this.contact);
    this.goto=function(name,pass)
    {

        var validUser = false;
        for(var a=0;a < $localStorage.myname.length;a++) {
            //console.log($localStorage.myname[a]);
            if ($localStorage.myname[a].name == name &&  $localStorage.myname[a].password == pass)
            {
                validUser = true;
                $localStorage.z = $localStorage.myname[a].name;
               // console.log(getdata);
               // console.log($localStorage.myname[a].name);
                $location.path('/view');


            }
        }

        if(validUser === false){
            alert('Invalid Details');
        }
    }
});



