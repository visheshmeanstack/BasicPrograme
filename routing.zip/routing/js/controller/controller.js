app.controller('Controller1', function ($scope) {
$scope.msg="hello pankaj";

  });
app.controller('Controller2', function ($scope) {
$scope.msg1="hello vishesh";

  });