var app =angular.module('myApp', ['ngRoute']);
app.config(['$routeProvider', function($routeProvider) {
    $routeProvider.
	 when('/veiw', {
        templateUrl: 'js/view/view.html',
        controller: 'Controller1'
    }).
	  when('/view2', {
        templateUrl: 'js/view/view2.html',
        controller: 'Controller2'
    })

}]);