var app=angular.module("myApp", []);
 app.controller("myCtrl", function($scope)
 {
   $scope.person={
		name:"rahul",
		last:"kumar",
		         };
	$scope.fullname =function()
	{
	var x= $scope.person;
	return x.name+" "+x.last;
	};
 });