'use strict';
angular.module('myApp', [
    www.it-ebooks.infoAngularJS Scope & Events
    'myApp.controllers'
]);
angular.module('myApp').run(function($rootScope){
    $rootScope.title='Famous Books';
    $rootScope.name="Root Scope";
});