var express = require('express');
var router = express.Router();
var model = require('../modules/usermodel');
var modelb = require('../modules/blogmodel');
var multer = require('multer');
var mime = require('mime-types');

//var Contactmodel = require('../modules/contactmodel');
var nodemailer = require('nodemailer');
var transporter = nodemailer.createTransport('smtps://freshervishesh@gmail.com:9991281944@smtp.gmail.com');
router.post('/contact1',function(req, res) {
 //var contact = new Contactmodel();
    var data = req.body;
 //contact.name = req.body.name;
 //contact.email = req.body.email;

    transporter.sendMail({
        from: data.email,
        to: 'avinash.thakur@mobilyte.com,kamalkishore273@gmail.com',       
        name:data.name,
        subject : "Message Show",       
        text: data.message
    });
 
    res.json(data);
});
//var upload = multer({ dest: 'uploads/' });





var storage = multer.diskStorage({
    destination: function (req, file, cb) {
        cb(null, './public/uploads/')
    },
    filename: function (req, file, cb) {
        console.log('file ',file);
        cb(null, Date.now()+'.'+ mime.extension(file.mimetype));
    }
});
var upload = multer({ storage: storage });


var blogimg = multer.diskStorage({
    destination: function (req, file, cb) {
        cb(null, './public/uploads/')
    },
    filename: function (req, file, cb) {
        console.log('file ',file);
        cb(null, Date.now()+'.'+ mime.extension(file.mimetype));
    }
});

var upload2 = multer({ storage: blogimg });









/* GET home page. */
// router.get('/', function(req, res, next) {
//   res.render('index', { title: 'Express' });
// });
//--------------------------------------------login  ---------------------------------------------
router.post('/login', function(req, res) {
	//console.log(req);
    //res.send(req.body);
  var email =  req.body.email;
    var password =  req.body.password;
    model.findOne({email:email},function(err,person){
    		if(err){
    			console.log("error",err);
    		}
    		else {

    			if(person){
    				if(person.password == password){
                         console.log(person);
                        //req.session.user=person;
    					res.send(person);

    					//res.render('home1',{data:person.firstname});
    					//res.send();
    				}
    				else{
    					console.log({error:'Incorrect Password'});
    				}
    			}
    			else{
    				console.log({error:"email not ragister"});
    			}
    		}

    });
});
//--------------------------view profile------------------------------



// -----------------------------------------------------singup user --------------------------------------

router.post('/signup',upload.single('file'), function(req, res){
    var user = new model();
    user.name = req.body.name;
    user.email = req.body.email;
    user.password = req.body.password;
    user.file = req.file.filename;
   //console.log(req.body.email);
    model.findOne({email:req.body.email},function(err,person){
        if(err){
            console.log('err',err)
        }else {
            if(!person){
                user.save(function (err, data) {
                    if (err) {
                        res.send(err);
                    }else {
                        console.log(data);
                       res.send(data);
                         
                    }
                });
            }else{
                res.send({error:'Email is already register'});
            }
        }
    });
});

//--------------------------------------------add blog  ---------------------------------------------
router.post('/blog', upload2.single('file'),function(req, res){
    var user = new modelb();
    user.title = req.body.title;
    user.tag = req.body.tag;
    user.msg = req.body.msg;
    user.file = req.file.filename;
     user.email = req.body.email;
      user.name = req.body.name;
//console.log(req.body);

    // model.findOne({title:req.body.title},function(err,person){
    //          if(err){
    //              console.log('err',err)
    //           }else {

    //             if(!person){

                user.save(function (err, data) {
                    if (err) {
                        res.send(err);
                    }else {
                        console.log(data);
                        res.send(data);
                    }
                });
        //         }else{
        //         res.send({error:'title is already register'});
        //     }
        // }
         
     
    });
    // });
   
//--------------------------------------------list blog  ---------------------------------------------

router.get('/list', function(req,res){
    modelb.find().sort({'_id': -1}).exec(function(err,data){
        if(err){
            res.send(err);
        }
        else{
            res.send(data);
            // console.log(data);
        }
    });
});
router.get('/list1/:email', function(req,res){
    modelb.find({email:req.params.email},function(err,data){
        if(err){
            res.send(err);
        }
        else{
            //console.log(data);
            res.send(data);
            
        }
    });
});

router.delete('/del/:id',function(req, res, next)
 {
    
    modelb.findById(req.params.id,function(err, person){
        person.remove(function(err,person){
            res.send(person);
        });
    });

});

router.get('/edit/:id', function(req,res){
    var uid=req.params.id;
    console.log(uid);
    modelb.findById(uid,function(err,data){
        if(err){
            res.send(err);
        }
        else{
            res.send(data);
        }
    });
});




router.post('/edit/:id', function(req, res){
    var uid = req.params.id; 
          modelb.findById(uid , function(err ,person){ 
          person.title= req.body.title; 
          person.tag= req.body.tag; 
          person.msg = req.body.msg;
          person.name = req.body.name;
         
                person.save(function (err, data) {
                    if (err) {
                        res.send(err);
                    }else {
                        res.send(data);
                    }
                });
                });
          });





/**
 * Send an email when the contact from is submitted
 */


            

module.exports = router;
