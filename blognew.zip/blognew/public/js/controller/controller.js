
//---------------------------------controller1-----------------------------------//

           //------------     login $$ signup users    -----------//

app.controller("controller1",function($scope,$location,$http,authuser,$localStorage){
	 $scope.signup=function(){
	 	$location.path('/signup');
	 }

	 $scope.login=function(){

	   authuser.Islogin($scope.email,$scope.pass);
 }


     $scope.userprofile=$localStorage.loginUser;
      console.log($scope.userprofile);



$scope.signUpUser = function(){
       var file = $scope.myFile;
 
       var uploadUrl = "api/signup";
        var fd = new FormData();
        fd.append('name',$scope.name);
        fd.append('email',$scope.email);
        fd.append('password',$scope.pass);
        fd.append('file', file);
       
        $http.post(uploadUrl,fd, {
            transformRequest: angular.identity,
            headers: {'Content-Type': undefined}
        }).then(function successCallback(response) {
		if(response.data.error){
			$scope.error = response.data.error;
		}else{
			
			$location.path('/login');

		}
	   //console.log(response);
	}, function errorCallback(response) {
	    console.log('error',response);
	});
    };

    
	

});

//------------------------------------------------------------------------------------

app.controller("controller2",function($scope,$location,$http){
	
	$scope.contact = function()
{
	$scope.error = " ";
	$http({
		method : 'POST',
		url : '/api/contact1',
		data : {name: $scope.name, email: $scope.email,  message : $scope.msg}
	}).then(function sucessCallback(response)
	{
		if(response.data.error)
		{
			$scope.error = response.data.error;
		}
		else{
			$location.path('/home');
		}
		console.log(response);
	}, function errorCallback(response){
		console.log(response);
	});
}
});


//---------------------------blog controllers---------------------------------------------//

       // blog Add  ------    blog show    -----   blog remove    ----------//

app.controller("blog",function($scope,$location,$http,$localStorage,authuser){
	$scope.data = $localStorage.user2;
	$scope.data1 = $localStorage.user3;
	 
	         $scope.currentPage = 1;
	         $scope.totalItems = $scope.data1.length;
	         $scope.entryLimit = 9; 
	         $scope.noOfpages = Math.ceil($scope.totalItems / $scope.entryLimit);

	//console.log($scope.data);

	$scope.addblog=function(){
 	    var file = $scope.myFile;
        var email=$localStorage.loginUser.email;
        var name =$localStorage.loginUser.name;
        var uploadUrl = "api/blog";
        var fd = new FormData();
	
        fd.append('title',$scope.title);
        fd.append('tag',$scope.tag);
        fd.append('msg',$scope.msg);
        fd.append('file', file);
        fd.append('email', email);
        fd.append('name', name);
      
        $http.post(uploadUrl,fd, {
            transformRequest: angular.identity,
            headers: {'Content-Type': undefined}
		
	}).then(function successCallback(response) {
		if(response.data.error){
			$scope.error = response.data.error;
		}else{
			
			$location.path('/list');

		}
	   //console.log(response);
	}, function errorCallback(response) {
	    console.log('error',response);
	});
    };



    //--------------------------view list-----------------

 angular.element(document).ready(function(){
 	$scope.error = '';
 	var email=$localStorage.loginUser.email;
 	//console.log(email);
	$http({
		method: 'GET',
		url: '/api/list1/'+email
		}).then(function successCallback(response) {
		if(response.data.error){
			$scope.error = response.data.error;
		}else{
			$scope.singluserlist = response.data;
			//console.log($scope.singluserlist);
          
			//$location.path('/blogadd');
		}
		
	}, function errorCallback(response) {
		console.log('error',response);
	});
});



// -------------------view home---------------------

 angular.element(document).ready(function(){
 	$scope.error = '';
	$http({
		method: 'GET',
		url: '/api/list'
	}).then(function successCallback(response) {
		if(response.data.error){
			$scope.error = response.data.error;
		}else{
			$scope.user = response.data;
			$localStorage.user3=$scope.user;
			//console.log($scope.user);
             
			
		}
		//console.log(response);
	}, function errorCallback(response) {
		console.log('error',response);
	});
});


$scope.delete=function(id){
 	$scope.error = '';
	$http.delete('/api/del/' + id)
            .success(function(data) {
               // $scope.user = data;
                //console.log(data);
                $location.path('/list');
            })
            .error(function(data) {
                console.log('Error: ' + data);
            });

 };
	
$scope.updateblog=function(id){
$scope.error = '';
	$http.get('/api/edit/' + id).then(function successCallback(response) {
		if(response.data.error){
			$scope.error = response.data.error;
		}else{
			$scope.user1 = response.data;
			//console.log($scope.user1);

             $localStorage.user2=$scope.user1;
             //console.log($localStorage.user2);
			$location.path('/edit1');
		}
		//console.log(response);
	}, function errorCallback(response) {
		console.log('error',response);
	});
};



$scope.updatesave=function(id){
 	$scope.error = '';
	$http({
		method: 'POST',
		url: '/api/edit/'+id ,
		data: {title:$scope.data.title,tag:$scope.data.tag, msg:$scope.data.msg}
	}).then(function successCallback(response) {
		if(response.data.error){
			$scope.error = response.data.error;
		}else{
			$location.path('/list');
		}
		console.log(response);
	}, function errorCallback(response) {
		console.log('error',response);
	});
};




//----------------------


$scope.view=function(id){
$scope.error = '';
	$http.get('/api/edit/' + id).then(function successCallback(response) {
		if(response.data.error){
			$scope.error = response.data.error;
		}else{
			$scope.user1 = response.data;
			//console.log($scope.user1);

             $localStorage.user2=$scope.user1;
             console.log($localStorage.user2);
			$location.path('/view');
		}
		//console.log(response);
	}, function errorCallback(response) {
		console.log('error',response);
	});
};








});
app.controller( 'mainCtrl', function( $scope, authuser,$location,$localStorage ) {
 
    $scope.checkuser= false;
    $scope.name=$localStorage.loginUser.name;
    $scope.LoginUser = function(){

     if(authuser.isCurrentLogin){
     	$scope.checkuser= true;
    }
    //$scope.name=$localStorage.loginUser.name;
    //console.log($scope.name);
};
$scope.logout = function(){
	authuser.isLogout();
	$scope.checkuser= false;

	$location.path('/login');

}

});



//-----------------------------------------------------------------------------

