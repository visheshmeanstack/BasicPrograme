app.factory('authuser', function($http,$location,$localStorage){
	var currentUser;
	return {
        Islogin:function(email,pass){
        	//console.log(email);
	 	    //console.log(pass);
        $http({
        	method:'POST',
        	url: '/api/login',
        	data:{email:email,password:pass}
        }).then(function successCallback(response){
                 //console.log(response.data);
                currentUser = response.data;
                $localStorage.loginUser1 = currentUser;
                console.log($localStorage.loginUser1);
                if($localStorage.loginUser1.email == email && $localStorage.loginUser1.password == pass)
                  {
                    $localStorage.loginUser = $localStorage.loginUser1;
                  $location.path('/home');
                  }

                 else{

                alert("You Entered worng Password && Email");
                 }


        	},function errorCallback(response){
               alert("You Entered worng Passwoed or email");
        	 //console.log('error',response);
                   });
        
        },


        isCurrentLogin:function(){
           return currentUser ? currentUser=true : currentUser=false;
        },

        isLogout:function(){
           return  currentUser=false;
        }


	};
});