var app = angular.module("myApp",['ngRoute','ngMessages','ui.bootstrap','myApp.directives','fileModel','ngStorage']);


app.config(function($routeProvider,$locationProvider){
$routeProvider.when('/home',{
	controller:'blog',
	templateUrl:'js/views/home.html'
}).when('/login',{
	controller:'controller1',
	templateUrl:'js/views/login.html'
}).when('/profile',{
  controller:'controller1',
  templateUrl:'js/views/profile.html'
}).when('/signup',{
	controller:'controller1',
	templateUrl:'js/views/singup.html'
}).when('/edit1',{
	controller:'blog',
	templateUrl:'js/views/edit.html'
}).when('/view',{
controller:'blog',
  templateUrl:'js/views/view.html'
}).when('/contact',{
	controller:'controller2',
	templateUrl:'js/views/contact.html'
}).when('/blogadd',{
	controller:'blog',
	templateUrl:'js/views/addblog.html'
}).when('/list',{
controller:'blog',
	templateUrl:'js/views/list.html'
}).
otherwise({
redirectTo:'/home'
	});
$locationProvider.html5Mode({
   enabled:true,
   requireBase: false
})
});
app.run(function($rootScope,authuser,$location){
  if(authuser.isCurrentLogin()){
    $location.path('/home');
  }else{
    $location.path('/home');
  }

});


var app = angular.module('myApp.directives', ['ngMessages']);
app.directive('compareTo', function () {
   return {
      require: "ngModel",
      scope: {
        otherModelValue: "=compareTo"
      },
      link: function(scope, element, attributes, ngModel) {

        ngModel.$validators.compareTo = function(modelValue) {
          return modelValue == scope.otherModelValue;
        };

        scope.$watch("otherModelValue", function() {
          ngModel.$validate();
        });
      }
    };
  });
var app = angular.module('fileModel', []);
app.directive('fileModel',  function ($parse) 
{
return {
    restrict: 'A',
    link: function(scope, element, attrs)
  {
        var model = $parse(attrs.fileModel);
        var modelSetter = model.assign;

        element.bind('change', function(){
            scope.$apply(function(){
                modelSetter(scope, element[0].files[0]);
            });
        });
       
     }
    };
});

  app.filter('startFrom', function () {
  return function (input, start) {
    if (input) {
      start = +start;
      return input.slice(start);
    }
    return [];
  };
});

