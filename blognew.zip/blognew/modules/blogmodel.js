var mongoose = require('mongoose');
var Schema = mongoose.Schema;

var userSchema = new Schema({
	title: {type:String,required: true},
    tag: {type:String,required: true},
    msg: {type:String,required: true},
    file:String,
    name:String,
    email:String
});


var User = mongoose.model('addblog', userSchema);

module.exports = User;