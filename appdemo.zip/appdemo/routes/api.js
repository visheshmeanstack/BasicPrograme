var express = require('express');
var router = express.Router();
var mongoose = require('mongoose');
var model = require('../model/usermodel');


/* GET home page. */
// router.get('/', function(req, res, next) {
//   res.render('index', { title: 'Express' });
// });
router.post('/log', function(req, res){
   var user =  new model();
   var email = req.body.email;
   var pass = req.body.pass;
   model.findOne({email:email} , function(err,person){
   if(err){
    			console.log("error",err);
    		}
    		else {
    			if(person){
    				if(person.pass == pass){
                         console.log(person);
                        //req.session.user=person;
    					res.send(person);

    					//res.render('home1',{data:person.firstname});
    					//res.send();
    				}
    				else{
    					console.log({error:'Incorrect Password'});
    				}
    			}
    			else{
    				console.log({error:"email not ragister"});
    			}
    		}
   });
});



router.post('/sss', function(req, res){
	var user = new model();
	user.name = req.body.name;
	user.email = req.body.email;
	user.pass = req.body.pass;
	model.findOne({email:req.body.email},function(err,person){
		if(err){
			console.log("Error");
		}
		else{
				if(!person)
				{
					user.save(function(err, blog){
						if(err){
							console.log(err);
							res.send(err);
							
						}
						else{
							console.log(blog);
							res.send(blog);
						}

					});
				}else {
					console.log("Email rgister");
				}
	        };
	});



 });
// router.get('/viewdata' , function(req,res){
//    	var user = new model();// 2nd hiest data
//    	model.find().sort({'_id':-1}).skip(1).limit(1).exec(function(err , person){
//    		if (err) {
//    		console.log("Error");	
//    		}
//    		else{
//    			res.send(person);
//    		}
//    	});
//    });
router.get('/viewdata' , function(req,res){
   	var user = new model();// 2nd hiest data
   	model.find().sort({'name':1}).exec(function(err , person){
   		if (err) {
   		console.log("Error");	
   		}
   		else{
   			res.send(person);
   		}
   	});
   });

module.exports = router;
