var app = angular.module('myApp',['ngRoute']);
app.config(function($routeProvider){
	$routeProvider.when('/home',{
	controller:'homeCtrl',
	templateUrl:'js/views/home.html'
	}).when('/login',{
	controller:'loginCtrl',
	templateUrl:'js/views/login.html'
	}).when('/signup',{
	controller:'loginCtrl',
	templateUrl:'js/views/signup.html'
	}).when('/view',{
	controller:'loginCtrl',
	templateUrl:'js/views/view.html'
	}).otherwise({
		redirectTo:'/home'
	})
})