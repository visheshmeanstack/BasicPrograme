app.controller('homeCtrl', function($scope,$location){
	$scope.msg = "Hello Mr. How Do you do ?";

	$scope.login = function(){
		$location.path('/login');
	}
	$scope.signup = function(){
		$location.path('/signup');
	}
});

//------------------logincontroller---------------------------
app.controller('loginCtrl', function($scope,$location,$http){
	
	$scope.signupuser = function(){
		//var name = $scope.name;
		//var pass = $scope.pass;
		//var email = $scope.email;
		$http({
			method:'POST',
			url:'/api/sss',
			data:{name:$scope.name,pass:$scope.pass,email:$scope.email}
		}).then(function successCallback(response){
			if(response.data.error){
				console.log('error');
			}
			else {
				$scope.data = response.data;
				 alert("Data Saved");
				 $location.path('/login');
			}
		},function errorCallback(response){
			console.log(response);
		});
	};

	$scope.loginuser = function(){
	    
		var pass = $scope.pass;
		var email = $scope.email;
		$http({
			method:'post',
			url:'/api/log',
			data:{email:$scope.email , pass:$scope.pass}
			
		}).then(function successCallback(response){
			if(response.data.error){
				alert('error');
			}
			else {
				//console.log(response);
				$scope.data1 = response.data;

				//console.log($scope.data1);
				if($scope.data1.pass == pass ){
				 alert("Data correct");
				 
				 $location.path('/view');
			}
			else{
				alert("wrong pasword");
			}
		}},function errorCallback(response){
			console.log(response.data.error);
		});
	};


    angular.element(document).ready(function(){
 		
 		$http({
 			method:'get',
 			url:'/api/viewdata'
 		}).then(function successCallback(response){
 			if(response.data.error){
 				console.log('error');
 			}
 			else {
 				$scope.users = response.data;
 				 //console.log($scope.users);
 				 //$location.path('/view');

 			}
 		},function errorCallback(response){
 			console.log('error');

 		});
    });
	
});