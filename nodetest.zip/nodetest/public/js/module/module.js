var app = angular.module('myApp',['ngRoute','ngStorage']);
app.config(function($routeProvider){
$routeProvider.when('/singup',{
	controller:'loginctrl',
	templateUrl:'js/views/singup.html'
}).when('/view',{
	controller:'myctrl',
	templateUrl:'js/views/view.html'
}).
otherwise({
	redirectTo:'/singup'
})
});