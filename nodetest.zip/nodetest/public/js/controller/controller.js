app.controller('loginctrl',function($scope,$location,$http,$localStorage){
	$scope.saveuser=function(){
    
 	$scope.error = '';
	$http({
		method: 'POST',
		url: '/api/singup/',
		data: {name:$scope.name,email:$scope.email, gender:$scope.gender,hobbies:$scope.hobbies,logitude:$scope.logitude,lagitutde:$scope.lagitutde}
	}).then(function successCallback(response) {
		if(response.data.error){
			$scope.error = response.data.error;
		}else{
			$localStorage.name1 =$scope.name;
			$location.path('/view');
		}
		console.log(response);
	}, function errorCallback(response) {
		console.log('error',response);
	});
};


});

// ====================================view cotrl-----------

app.controller('myctrl',function($scope,$location,$http,$localStorage){

angular.element(document).ready(function(){
 	//$scope.email = '';
 	var email=$localStorage.name1;
 	//console.log(email);
	$http({
		method: 'GET',
		url: '/api/list1/'+name1
		}).then(function successCallback(response) {
		if(response.data.error){
			$scope.error = response.data.error;
		}else{
			$scope.user = response.data;
			//console.log($scope.singluserlist);
          
			$location.path('/view');
		}
		
	}, function errorCallback(response) {
		console.log('error',response);
	});
});


});