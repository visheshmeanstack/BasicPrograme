var express = require('express');
var router = express.Router();
var mongoose = require('mongoose');
var model = require('../model/usermodel');

/* GET home page. */
// router.get('/', function(req, res, next) {
//   res.render('index', { title: 'Express' });
// });

router.post('/singup', function(req, res){
        var user = new model();
        user.name = req.body.name;
         user.email = req.body.email;
         user.gender = req.body.gender;
         user.hobbies = req.body.hobbies;
         user.logitude = req.body.logitude;
         user.lagitutde = req.body.lagitutde;
    

   //console.log(req.body.email);
    model.findOne({email:req.body.email},function(err,person){
        if(err){
            console.log('err',err)
        }else {
            if(!person){
                user.save(function (err, data) {
                    if (err) {
                        res.send(err);
                    }else {
                        console.log(data);
                       res.send(data);
                         
                    }
                });
            }else{
                res.send({error:'username is already register'});
            }
        }
    });
});

router.get('/list1/:email', function(req, res){
        var user = new model();
         model.findOne({email:req.params.name},function(err,person){
        if(err){
            console.log('err',err)
        }else {
           
                   console.log(person);
                   res.send(person);
                         
                    }
                });
            
       
    });


module.exports = router;
