var mongoose = require('mongoose');
var Schema = mongoose.Schema;

var userSchema = new Schema({
	name:String,
	age:String,
	email:{type:String , unique:true, required:true},
	
	hobbies:String,
	logitude:String,
	lagitutde:String
});
var user = mongoose.model('users' ,userSchema);
module.exports = user;